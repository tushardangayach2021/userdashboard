//  All action types are here
export const Add_USER = 'Add_USER';
export const SIGIN_USER = 'SIGIN_USER';
export const SIGNOUT_USER = 'SIGNOUT_USER';
