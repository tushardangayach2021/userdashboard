export const InitialForm = {
    firstname: '',
    lastname: '',
    email: '',
    dob: '',
}