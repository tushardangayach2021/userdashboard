export const API = {
    AUTH: {
        REGISTER: '/register'
    },
    CORE: {
        USERNAME: "/name",
        USEREMAIL: "/email",
    }
}